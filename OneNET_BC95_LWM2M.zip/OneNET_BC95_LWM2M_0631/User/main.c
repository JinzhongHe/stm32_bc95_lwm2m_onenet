/**
 * Copyright (c) 2017 China Mobile IOT.
 * All rights reserved.
 ����˵��:
 1.�ó�����Heskey����������������M5310ģ���Demo��ֲ��������������Զ��BC95_B8ģ��,������ԭ�������һ�£��������÷�����main.c��bc95_config.h���ע�͡�
 2.Ϊ�˷�����ʹ�ã���ȥ���˴��������������룬��ֵ��д���ˣ��ɸ����Լ�����Ҫ���Ӵ������������룬����read_callback()��res_update()��������Ӧλ���滻Ϊ���Լ��Ĵ�����ֵ��
 3.���׵Ĺ̼�����ع����ֲ��ҽ�����ѹ�����ڣ������ļ��д�š�
**/
#include <nbiot.h>
#include <utils.h>
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include "platform.h"
#include "delay.h"
#include "bc95_config.h" /*��Ŀ��������ͷ�ļ�����obj�ܸ�����discover obj������observe obj�����б�ʱ��Ҫ�޸ĸ�ͷ�ļ�������*/
#include "led.h"
nbiot_value_t Temp;   //�¶� 
nbiot_value_t Humi;   //ʪ��
nbiot_value_t illumi;  //����
nbiot_value_t LED; //LED
nbiot_value_t press;  //ѹ��
nbiot_value_t altitude; //����
nbiot_value_t acceleX;//�������x
nbiot_value_t acceleY;//�������y
nbiot_value_t acceleZ;//�������z
valueString_list_t valueString_list[MAX_OBJECT_SUM]={{3304,0,"5700"},
                                                    {3303,0,"5700"},
																								    {3311,0,"5850"},
																										{3301,0,"5700"},
																										{3202,0,"5600"}
                                                     };  /*��ʹ�õ�resid��ͬʱ����Ҫ�޸����{objid,instid,valueString},��ʵ��instid��Ϊ0,�ʲ����޸ģ�valueString����ʽΪ"5700;5850",�����Լ���������*/

void write_callback( uint16_t       objid,
                     uint16_t       instid,
                     uint16_t       resid,
                     nbiot_value_t *data ) 
{
    printf( "write /%d/%d/%d��%d\r\n",
                  objid,
                  instid,
                  resid,data->value.as_bool );
    if(objid==3311&&instid==0&&resid==5850)
		{  
			 Led1_Set(data->value.as_bool);
		}
}

void read_callback( uint16_t       objid,
                     uint16_t       instid,
                     uint16_t       resid,
                     nbiot_value_t *data )
{

		   
       if(objid==3303&&instid==0&&resid==5700){
				 
				  Temp.value.as_float=(int64_t)17;
		
		    }else if(objid==3304&&instid==0&&resid==5700){
					
				  Humi.value.as_float=(int64_t)56;
	      }else if(objid==3301&&instid==0&&resid==5700)
				{
        illumi.value.as_float=	(int64_t)2000;	
				}
				else if(objid==3302&&instid==3&&resid==5600)
				{
        illumi.value.as_float=	(int64_t)30;	
				}
				else if(objid==3302&&instid==4&&resid==5600)
				{
        illumi.value.as_float=	(int64_t)40;	
				}
				else if(objid==3302&&instid==5&&resid==5600)
				{
        illumi.value.as_float=	(int64_t)50;	
				}
				else if(objid==3302&&instid==6&&resid==5600)
				{
        illumi.value.as_float=	(int64_t)50;	
				}
				else if(objid==3302&&instid==7&&resid==5600)
				{
        illumi.value.as_float=	(int64_t)50;	
				}


}

void execute_callback( uint16_t       objid,
                       uint16_t       instid,
                       uint16_t       resid,
                       nbiot_value_t *data,
                       const void    *buff,
                       size_t         size )
{
    printf( "execute /%d/%d/%d\r\n",
                  objid,
                  instid,
                  resid );
}

nbiot_device_t *dev = NULL;
uint8_t inscount = 0;

time_t last_time=0;
time_t cur_time=0;


void res_update(time_t interval)
{
				char tmp[10];
       if(cur_time>=last_time+interval){ 
            cur_time=0;
            last_time=0;				 
				    Temp.flag |= NBIOT_UPDATED;		
            Humi.flag |= NBIOT_UPDATED;  
			      Temp.value.as_float=(int64_t)17;
				    Humi.value.as_float=(int64_t)56;	
				    illumi.flag |= NBIOT_UPDATED;
				    illumi.value.as_float=	(int64_t)20000;
				    press.flag |= NBIOT_UPDATED;
				    altitude.flag |= NBIOT_UPDATED;
            acceleX.flag |= NBIOT_UPDATED;		
            acceleY.flag |= NBIOT_UPDATED;
            acceleZ.flag |= NBIOT_UPDATED;
            press.value.as_float=30;
            altitude.value.as_float=40;				 
						acceleX.value.as_float=50;
						acceleY.value.as_float=60;
						acceleZ.value.as_float=70;	
            				 
			}else if(cur_time==0&&last_time==0){
			
			    cur_time=nbiot_time();
			    last_time=cur_time;
			
			}else{
			
			   cur_time=nbiot_time();
			   
			} 	 

}	
int main(void)
{
     int life_time = 300;
	   int ret;
     nbiot_init_environment();  
        ret = nbiot_device_create( &dev,
                                   life_time,
                                   write_callback,
                                   read_callback,
                                   execute_callback );
        if ( ret )
        {
            nbiot_device_destroy( dev );
            printf( "device creat failed, code = %d.\r\n", ret );
        }
				LED.type = NBIOT_BOOLEAN;
        LED.flag = NBIOT_READABLE|NBIOT_WRITABLE;
        ret = nbiot_resource_add( dev,
                                  3311, 
                                  0,  
                                  5850, 
				                          1, 
				                          0, 
                                  &LED,//LED
				                          0, 
                                  1); 
        if ( ret )
        {
            nbiot_device_destroy( dev );
            printf( "device add resource(LED) failed, code = %d.\r\n", ret );
        }
        Temp.type = NBIOT_FLOAT;
        Temp.flag = NBIOT_READABLE;
        ret = nbiot_resource_add( dev,
                                  3303,
                                  0,
                                  5700,
				                          1,
				                          0,
                                  &Temp,//�¶�
				                          0,
				                          1);
        if ( ret )
        {
            nbiot_device_destroy( dev );
            printf( "device add resource(temp) failed, code = %d.\r\n", ret );
        }
        Humi.type = NBIOT_FLOAT;
        Humi.flag = NBIOT_READABLE;
        ret = nbiot_resource_add( dev,
                                  3304,
                                  0,
                                  5700,
				                          1,
				                          0,
                                  &Humi,//ʪ��
				                          0,
				                          1);
        if ( ret )
        {
            nbiot_device_destroy( dev );
            printf( "device add resource(humi) failed, code = %d.\r\n", ret );
        }
				illumi.type = NBIOT_FLOAT;
        illumi.flag = NBIOT_READABLE;
        ret = nbiot_resource_add(dev,
                                  3301,
                                  0,
                                  5700,
				                          1,
				                          0,
                                  &illumi,//����
				                          0,
				                          1);
        if ( ret )
        {
            nbiot_device_destroy( dev );
            printf( "device add resource(illumi) failed, code = %d.\r\n", ret );
        }
				press.type = NBIOT_FLOAT;
        press.flag = NBIOT_READABLE;
        ret = nbiot_resource_add( dev,
                                  3202,//objid
                                  3,//instid
                                  5600,//resid
				                          1,//IsRW,�Ƿ�ɶ�д:��,1:��,0
				                          0,//IsExec,�Ƿ��ִ��:��,1:��,0
                                  &press,//ѹ��
                                  1,//��ͬһobjid��Ҫ�������instʱ(��֧��������instid)�������һ��instid��Ϊ0,��Ҫ���øò���Ϊ1���ҽ��ڵ�һ��inst�����øò���������inst�ò���������Ϊ0
                                  0);//ͬһobjid�µ�ʵ���Ƿ񴴽���ɵı�־�����Ϊ1��û���Ϊ0�����ڴ���ͬһobjid�����һ��resʱ�����ò�������Ϊ1
        if ( ret )
        {
            nbiot_device_destroy( dev );
            printf( "device add resource(press) failed, code = %d.\r\n", ret );
        }
				altitude.type = NBIOT_FLOAT;
        altitude.flag = NBIOT_READABLE;
        ret = nbiot_resource_add( dev,
                                  3202,
                                  4,
                                  5600,
				                          1,
				                          0,
                                  &altitude,//����
                                  0,
                                  0);
        if ( ret )
        {
            nbiot_device_destroy( dev );
            printf( "device add resource(altitude) failed, code = %d.\r\n", ret );
        }
				acceleX.type = NBIOT_FLOAT;
        acceleX.flag = NBIOT_READABLE;
        ret = nbiot_resource_add( dev,
                                  3202,
                                  5,
                                  5600,
				                          1,
				                          0,
                                  &acceleX,//x��
                                  0,
                                  0);
        if ( ret )
        {
            nbiot_device_destroy( dev );
            printf( "device add resource(acceleX) failed, code = %d.\r\n", ret );
        }
				acceleY.type = NBIOT_FLOAT;
        acceleY.flag = NBIOT_READABLE;
        ret = nbiot_resource_add( dev,
                                  3202,
                                  6,
                                  5600,
				                          1,
                                  0,
                                  &acceleY,//y��
				                          0,
                                 	0);
        if ( ret )
        {
            nbiot_device_destroy( dev );
            printf( "device add resource(acceleY) failed, code = %d.\r\n", ret );
        }
				acceleZ.type = NBIOT_FLOAT;
        acceleZ.flag = NBIOT_READABLE;
        ret = nbiot_resource_add( dev,
                                  3202,
                                  7,
                                  5600,
								                  1,
				                          0,
                                  &acceleZ,//z��
				                          0,
				                          1);
        if ( ret )
        {
            nbiot_device_destroy( dev );
            printf( "device add resource(acceleZ) failed, code = %d.\r\n", ret );
        }
        ret = nbiot_device_connect(dev,60);

        if ( ret )
        {
            nbiot_device_close( dev, 100);
            nbiot_device_destroy( dev );
            printf( "connect OneNET failed.\r\n" );
					  nbiot_reset();
        }else{
					  Led4_Set(LED_ON);
				    printf( "connect OneNET success.\r\n" );
				 
				}
     do
    {        
             ret = nbiot_device_step( dev, 1);
             if ( ret )
             {
                 printf( "device step error, code = %d.\r\n", ret );
             } 
          	res_update(5);					 
			      
    } while(1);
    nbiot_clear_environment();


    return 0;
}
