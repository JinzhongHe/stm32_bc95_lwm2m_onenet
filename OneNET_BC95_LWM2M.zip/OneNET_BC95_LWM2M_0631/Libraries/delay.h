#ifndef DELEY_H
#define DELEY_H
#include <stdint.h>
void mDelay(uint32_t milliseconds);
void uDelay(uint32_t i);
void nbiot_sleep( int milliseconds);

#endif
